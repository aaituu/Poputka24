<!--index.php-->
<?php
// Устанавливаем время жизни сессии в 24 часа (86400 секунд)
session_set_cookie_params(86400); // 86400 секунд = 24 часа
session_start();
?>

<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="keywords" content="Poputka.kz, попутка, полпутчик, poputki, сайт грузоперевозок, пассажирские перевозки, найти попутку">
    <title>Poputka</title>
    <link rel="stylesheet" href="/css/style.css" />
    <link rel="icon" href="/favicon.ico" type="image/ico">
  </head>
  <body>
    <header>
      <div class="logo">
        <h1>Poputka</h1>
      </div>
      <nav>
            <!-- <a href="#">Home</a>
            <a href="#">Services</a>
            <a href="#">Contact Us</a> -->
            <a href="profile.php">Профиль</a>
      </nav>
    </header>

    <section class="hero-section">
      <div class="hero-content">
        <!-- Проверяем, авторизован ли пользователь -->

        <a href="/auth/logout"><button class="ExitBtn">Выйти</button></a>
        
        <!-- Кнопка для выхода -->
        <!-- Если не авторизован -->
        <a href="login.php"><button class="tak">Авторизация</button></a>
        <a href="register.php"><button>Регистрация</button></a>

        <h1>Добро пожаловать в Poputka!<?php
                    // Проверяем, авторизован ли пользователь
            if (isset($_SESSION['username'])) {
                echo " " . htmlspecialchars($_SESSION['username']) . "";
            } else {
                 echo "Привет, гость!";
            }
        ?></h1>
        <meta name="description" content="Мы предлагаем пассажирские и грузоперевозоки по всему Казахстану с выездом в зарубежные страны">
        <p>Пассажирские и грузовые перевозки</p>
        <a href="createOrder.php"><button class="CreateBtn">Создать заказ</button></a>
        <a href="orders.php"><button>Посмотреть заказы</button></a>
        <!-- Кнопка для создания заказа -->
      </div>
    </section><br><br>
    <section class="bottom">
      <h1>
        У вас есть идеи для улучшения приложения?<br />
        Или вам встретился недобросовестный пользователь?<br>
        <a
          href="mailto:Poputka.kz@list.ru?subject=Тема письма&body=Текст письма">
          Написать нам на почту Poputka.kz@list.ru
        </a>
      </h1>
    </section>
  </body>
</html>

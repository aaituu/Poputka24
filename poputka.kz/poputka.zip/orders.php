<?php
// Подключаемся к базе данных
$conn = new mysqli('localhost', 'root', '', 'poputka');
if ($conn->connect_error) {
    die('Ошибка подключения: ' . $conn->connect_error);
}

// Получаем все заказы
$sql = "SELECT * FROM orders";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Список заказов</title>
    <link rel="stylesheet" href="/css/orders.css">
</head>
<body>
    <h1>Список заказов</h1>
    <ul>
        <?php
        if ($result->num_rows > 0) {
            while ($order = $result->fetch_assoc()) {
                // Проверяем наличие всех нужных полей
                $type = $order['type'] ?? 'Не указан';
                $region = $order['region'] ?? 'Не указана';
                $from_location = $order['from_location'] ?? 'Не указано';
                $to_location = $order['to_location'] ?? 'Не указано';
                $description = $order['description'] ?? 'Без описания';

                echo "<li>
                        <a href='/orderDetails.php?id={$order['id']}'>
                            <strong>Тип:</strong> $type 
                            <strong>Область:</strong> $region
                            <strong>Откуда:</strong> $from_location 
                            <strong>Куда:</strong> $to_location 
                            <strong>Описание:</strong> $description
                        </a>
                    </li>";
            }
        } else {
            echo "<li>Нет заказов.</li>";
            
        }
        ?>
    </ul>
</body>
</html>

<?php
$conn->close();
?>
